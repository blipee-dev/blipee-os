'use client'

import Link from 'next/link'
import styles from '../landing.module.css'
import { navLinks } from '../content/data'

export function Navbar() {
  return (
    <nav className={styles.nav}>
      <div className={styles.navContainer}>
        <Link href="/" className={styles.logo}>
          blipee
        </Link>
        <ul className={styles.navLinks}>
          {navLinks.map(link => (
            <li key={link.href}>
              {link.prominent ? (
                <Link href={link.href} className={`${styles.navButton} ${styles.primaryButton}`}>
                  {link.label}
                </Link>
              ) : (
                <Link href={link.href} className={styles.navLink}>
                  {link.label}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>
    </nav>
  )
}
