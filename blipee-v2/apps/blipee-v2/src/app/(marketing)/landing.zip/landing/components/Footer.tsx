'use client'

import styles from '../landing.module.css'
import { footerSections, footerSummary, footerSocial } from '../content/data'
import { ThemeToggleButton } from './ThemeToggleButton'
import type { ThemeMode } from '../hooks/useThemeToggle'

type FooterProps = {
  themeMode: ThemeMode
  onThemeChange: (mode: ThemeMode) => void
}

export function Footer({ themeMode, onThemeChange }: FooterProps) {
  return (
    <footer className={styles.footer}>
      <div className={styles.footerContent}>
        <div className={`${styles.footerDivider} ${styles.footerDividerTop}`} />

        <div className={styles.footerGrid}>
          <div className={`${styles.footerBrand} ${styles.footerSection}`}>
            <div className={styles.footerLogo}>{footerSummary.brand}</div>
            <p className={styles.footerDescription}>{footerSummary.description}</p>
            <div className={styles.socialLinks}>
              {footerSocial.map(link => (
                <a key={link.label} href={link.href} className={styles.socialLink} aria-label={link.label}>
                  {link.icon}
                </a>
              ))}
            </div>
            <div className={styles.footerToggle}>
              <ThemeToggleButton mode={themeMode} onChange={onThemeChange} variant="footer" />
            </div>
          </div>

          {footerSections.map(section => (
            <div key={section.title} className={styles.footerSection}>
              <h4 className={styles.footerSectionTitle}>{section.title}</h4>
              <ul className={styles.footerLinks}>
                {section.links.map(link => (
                  <li key={link.href}>
                    <a href={link.href} className={styles.footerLink}>
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className={styles.footerSection}>
            <h4 className={styles.footerSectionTitle}>Stay Updated</h4>
            <p className={styles.footerDescription}>
              Get the latest sustainability insights and product updates.
            </p>
            <form className={styles.newsletterForm}>
              <input
                type="email"
                required
                className={styles.newsletterInput}
                placeholder={footerSummary.newsletterPlaceholder}
              />
              <button type="submit" className={`${styles.navButton} ${styles.primaryButton}`}>
                {footerSummary.newsletterCta}
              </button>
            </form>
          </div>
        </div>

        <div className={`${styles.footerDivider} ${styles.footerDividerBottom}`} />

        <div className={styles.footerBottom}>
          <p>{footerSummary.copyright}</p>
          <div className={styles.footerBottomLinks}>
            <a href="/privacy" className={styles.footerBottomLink}>
              Privacy Policy
            </a>
            <a href="/terms" className={styles.footerBottomLink}>
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
